
import 'package:dictionary1/screens/homepage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: HomePage(),));
}
